const testo = 'Sto imparando JavaScript';
//MAIUSCOLA
document.getElementById('maiuscola').innerHTML = testo.toUpperCase();
//MINUSCOLA
document.getElementById('minuscola').innerHTML = testo.toLowerCase();
//StrARRAY
document.getElementById('strArray').innerHTML = testo.split("");;
//ESTRAZIONE CARATTERI
var estraiCaratteri = testo.substr(2,1);
document.getElementById('estraiCaratteri').innerHTML += estraiCaratteri;
var estraiCaratteri2 = testo.substr(1,1);
document.getElementById('estraiCaratteri').innerHTML += estraiCaratteri2;
var estraiCaratteri3 = testo.substr(14,1);
document.getElementById('estraiCaratteri').innerHTML += estraiCaratteri3;
var estraiCaratteri4 = testo.substr(18,1);
document.getElementById('estraiCaratteri').innerHTML += estraiCaratteri4;
//CONCATENA
document.getElementById('concatena').innerHTML += testo.concat(' ','JS');
//ESTRAI STRINGA
document.getElementById('estraiStringa').innerHTML += testo.substr(5,4);;
//ARRAY
const alunni = ['Giovanni','Carla','Piero','Mirtilla'];
document.getElementById('array').innerHTML = alunni;
document.getElementById('lunghezza').innerHTML = alunni.length
document.getElementById('elemento').innerHTML = alunni.slice(2,3);
document.getElementById('ultimo').innerHTML = alunni.slice(3);
var modificato = alunni.splice(2,1,'Massimo');
document.getElementById('modificato').innerHTML = alunni;
//ARRAY COME FUNZIONE
const annoNascita = [1998, 1991, 1992, 1995, 2000]
const annoAttuale = 2022;
calcolaEta()
function calcolaEta () {
    let miaEta1 = annoAttuale - annoNascita [0];
    let miaEta2 = annoAttuale - annoNascita [1];
    let miaEta3 = annoAttuale - annoNascita [2];
    let miaEta4 = annoAttuale - annoNascita [3];
    let miaEta5 = annoAttuale - annoNascita [4];
    etatotale(miaEta1, miaEta2, miaEta3, miaEta4, miaEta5);
}
function etatotale (ee1, ee2, ee3, ee4, ee5){
document.getElementById('eta1').innerHTML += `${ee1} anni`;
document.getElementById('eta2').innerHTML += `${ee2} anni`;
document.getElementById('eta3').innerHTML += `${ee3} anni`;
document.getElementById('eta4').innerHTML += `${ee4} anni`;
document.getElementById('eta5').innerHTML += `${ee5} anni`;
const sos = [ee1, ee2, ee3, ee4, ee5];
document.getElementById('arrayEta').innerHTML += sos.toString();
}

//ARRAY ANIMALI
const animali = ['coniglio','cane','gatto','criceto'];
document.getElementById('intero').innerHTML = animali;
var aggiunto = animali.push('leone');
document.getElementById('aggiunto').innerHTML = animali;
var estratto = animali.pop();
document.getElementById('estratto').innerHTML = animali;
var verifica1 = animali.includes('cane');
document.getElementById('verifica1').innerHTML = verifica1;
var verifica2 = animali.includes('leone');
document.getElementById('verifica2').innerHTML = verifica2;